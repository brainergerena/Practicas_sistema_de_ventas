package com.example.delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
