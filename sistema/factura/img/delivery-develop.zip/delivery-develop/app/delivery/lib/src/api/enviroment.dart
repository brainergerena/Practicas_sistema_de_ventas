class Enviroment {
  static const String API_DELIVERY = "172.16.102.186:3000";
}
