import 'package:flutter/material.dart';

class MyColors {
  static Color primaryColor = Color(0xFFE70D32);
  static Color primaryColorDark = Color(0xFFA7001C);
  static Color primaryOpacityColor = Color.fromRGBO(231, 13, 50, 0.09);
}
